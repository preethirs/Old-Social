var fs = require('fs');
var srcdata = fs.readFileSync('ps_ngss_audio_G3_12.json');
var src = JSON.parse(srcdata);

var mapdata = fs.readFileSync('ps_mapping_audio_G3_12.json');
var map = JSON.parse(mapdata);

var tardata = fs.readFileSync('ps_cpl_template_G3_12.json');
var tar = JSON.parse(tardata);
var counter = 0;
var src_array = 0;
var tar_array = 0;
var temp = 0;
var temp1 = 0;
var temp_2 = 0;
var buff_array = new Array();
var tar_buff_array = new Array();
var mod_buff_arr = new Array();
var mod_buff_arr_1 = new Array();
var mod_buff_arr_2 = new Array();

var mod_tar_arr = new Array();
var buff_array_pl = new Array();
var tar_buff_array_pl = new Array();
var mod_buff_arr_pl = new Array();
var mod_tar_arr_pl = new Array();
var mcq_correct_value= 0;

async function audio_map(currentbuffer, map_data, target,mcq_correct_value) {
    console.log(mcq_correct_value,"   received correct value  ",target);
  var temp = 0;
  if (counter < map_data.length) {
      if (map_data[counter].data_type == "text") {
          console.log("text")
          for (j = 0; j < target[map_data[counter].array_type].length; j++) {
              if (map_data[counter].target_key_name == target[map_data[counter].array_type][j][map_data[counter].reference_name]) {

                  for (i = 0; i < currentbuffer[map_data[counter].array_type].length; i++) {
                      if (map_data[counter].source_key_name == currentbuffer[map_data[counter].array_type][i][map_data[counter].reference_name]) {
                          target[map_data[counter].array_type][j][map_data[counter].parent_name_1] = currentbuffer[map_data[counter].array_type][i][map_data[counter].parent_name_1]
                          target[map_data[counter].array_type][j][map_data[counter].parent_name_2] = currentbuffer[map_data[counter].array_type][i][map_data[counter].parent_name_2]
                      }
                  }
              }
          }
      } else if (map_data[counter].data_type == "caption" || map_data[counter].data_type == "content" || map_data[counter].data_type == "title" || map_data[counter].data_type == "option" || map_data[counter].data_type == "draggable") {
          for (i = 0; i < currentbuffer[map_data[counter].array_type].length; i++) {

              buff_array.push(i)
              if (currentbuffer[map_data[counter].array_type][i][map_data[counter].reference_name] == map_data[counter].source_key_name + "-" + temp) {
                  mod_buff_arr.push(buff_array[i]);
                  temp++;
              } else {
                  temp = 0;
              }
              console.log(buff_array)
          }
          for (j = 0; j < target[map_data[counter].array_type].length; j++) {
              tar_buff_array.push(j)
              console.log(tar_buff_array)
          }

          for (i = 0; i < tar_buff_array.length; i++) {
              console.log("counter", counter)

              if (target[map_data[counter].array_type][i] != undefined) {
                debugger;
                  if (target[map_data[counter].array_type][i][map_data[counter].reference_name] == map_data[counter].target_key_name + "-" + temp) {
                      mod_tar_arr.push(tar_buff_array[i]);

                      console.log(mod_tar_arr)
                      if (mod_tar_arr.length > mod_buff_arr.length) {
                          console.log("rare", target[map_data[counter].array_type][i][map_data[counter].reference_name], i, temp, mod_tar_arr[i], mod_tar_arr.length)

                          //target[map_data[counter].array_type].splice(mod_tar_arr[temp], mod_tar_arr.length + 1);
                          target[map_data[counter].array_type].splice(i,1);
                          i=i-1;


                      } else {
                          for (m = 0; m < buff_array.length; m++) {
                            if(map_data[counter].inside_trackid == "response"){
                              target[map_data[counter].array_type][tar_buff_array[i]][map_data[counter].parent_name_1] = "00:00:00.000";
                              target[map_data[counter].array_type][tar_buff_array[i]][map_data[counter].parent_name_2] = "00:00:00.001";

                            }else {
                              if (currentbuffer[map_data[counter].array_type][m][map_data[counter].reference_name] == map_data[counter].source_key_name + "-" + temp) {
                                  target[map_data[counter].array_type][tar_buff_array[i]][map_data[counter].parent_name_1] = currentbuffer[map_data[counter].array_type][buff_array[m]][map_data[counter].parent_name_1]
                                  target[map_data[counter].array_type][tar_buff_array[i]][map_data[counter].parent_name_2] = currentbuffer[map_data[counter].array_type][buff_array[m]][map_data[counter].parent_name_2]
                              }

                            }
                          }
                      }
                      temp++
                      if(map_data[counter].inside_trackid == "correct_feedback.incorrect_feedback"){

                        let correct_incorect=map_data[counter].inside_trackid;
                        let correct_incorect_split= correct_incorect.split(".");
                        let feedback_temp= target[map_data[counter].array_type][tar_buff_array[i]][map_data[counter].reference_name]
                        let feedback_temp_split=  feedback_temp.split("-");
                        for(b=0; b< buff_array.length; b++ ){
                          if(feedback_temp_split[1] == mcq_correct_value){
                              if(currentbuffer[map_data[counter].array_type][b][map_data[counter].reference_name] == correct_incorect_split[0] ){
                                target[map_data[counter].array_type][tar_buff_array[i]][map_data[counter].parent_name_1] = currentbuffer[map_data[counter].array_type][buff_array[b]][map_data[counter].parent_name_1]
                                target[map_data[counter].array_type][tar_buff_array[i]][map_data[counter].parent_name_2] = currentbuffer[map_data[counter].array_type][buff_array[b]][map_data[counter].parent_name_2]

                              }
                          }
                          else if(currentbuffer[map_data[counter].array_type][b][map_data[counter].reference_name] == correct_incorect_split[1] ){
                          target[map_data[counter].array_type][tar_buff_array[i]][map_data[counter].parent_name_1] = currentbuffer[map_data[counter].array_type][buff_array[b]][map_data[counter].parent_name_1]
                          target[map_data[counter].array_type][tar_buff_array[i]][map_data[counter].parent_name_2] = currentbuffer[map_data[counter].array_type][buff_array[b]][map_data[counter].parent_name_2]
                        }
                        }
                        debugger;
                        console.log("mcq_correct_value  ",mcq_correct_value);
                         for(pl=0;pl< target[map_data[counter].array_type_pl].length; pl++){
                           if(target[map_data[counter].array_type_pl][pl][map_data[counter].reference_name] == "CorrectSingle"){
                            if(map_data[counter].data_type_pl=="mcq_ss"){
                               target[map_data[counter].array_type_pl][pl]= {
                               "id": "CorrectSingle",
                               "trackIds": [
                                 "optionsCannedResponse-"+ mcq_correct_value,
                                 "optionsFeedback-"+ mcq_correct_value
                               ]
                             };
                           } else{
                             target[map_data[counter].array_type_pl][pl]= {
                               "id": "CorrectSingle",
                               "trackIds": []
                                 
                             };
                           }
                            
                           }
                         }




                      }
                  } else {
                      temp = 0
                  }
              }
          }
          if (map_data[counter].inside_trackid == "trackIds") {
              for (l = 0; l < target[map_data[counter].array_type_pl][0][map_data[counter].inside_trackid].length; l++) {
                  var temp_push = target[map_data[counter].array_type_pl][0][map_data[counter].inside_trackid][l]
                  var temp_push_split = temp_push.split("-");

                  if (temp_push == map_data[counter].target_key_name + "-" + temp_push_split[1]) {
                      mod_buff_arr_1.push(l)
                      //console.log(target[map_data[counter].array_type_pl][0][map_data[counter].inside_trackid][l], "+++++++++++", mod_buff_arr_1)
                  }
              }


              for (k = 1; k < target[map_data[counter].array_type_pl].length; k++) {
                  var temp_push1 = target[map_data[counter].array_type_pl][k][map_data[counter].reference_name]
                  var temp_push_split1 = temp_push1.split("-");

                  if (temp_push1 == map_data[counter].data_type_pl+ "-" + temp_push_split1[1]) {
                      mod_buff_arr_2.push(k)
                      console.log(target[map_data[counter].array_type_pl][k], mod_buff_arr_2, "-----------")
                  }
              }
              if (mod_buff_arr.length < mod_buff_arr_1.length) {
                  target[map_data[counter].array_type_pl][0][map_data[counter].inside_trackid].splice(mod_buff_arr_1[mod_buff_arr.length], (mod_buff_arr_1.length - mod_buff_arr.length))
                  //console.log(target[map_data[counter].array_type_pl][0][map_data[counter].inside_trackid], "+++++++++++", mod_buff_arr_1, mod_buff_arr)
              }
              if (mod_buff_arr.length < mod_buff_arr_2.length) {
                  target[map_data[counter].array_type_pl].splice(mod_buff_arr_2[mod_buff_arr.length], (mod_buff_arr_2.length - mod_buff_arr.length))
                  //console.log(target[map_data[counter].array_type_pl][0][map_data[counter].inside_trackid], "+++++++++++", mod_buff_arr_1, mod_buff_arr)
              }


          }
      }else if (map_data[counter].data_type == "srcpath") {
          for (i = 0; i < target[map_data[counter].array_type].length; i++) {
            target[map_data[counter].array_type][i][map_data[counter].parent_name_1] = "../../" +currentbuffer[map_data[counter].array_type][0][map_data[counter].parent_name_1]
          }
      }
      counter++;
      buff_array = [];
      tar_buff_array = [];
      mod_buff_arr = [];
      mod_tar_arr = [];
      mod_buff_arr_1 = [];
      mod_buff_arr_2 = [];
      audio_map(currentbuffer, map_data, target, mcq_correct_value);
  } else {
      console.log("test")
  }
  }
  audio_map(src, map.mapping_data, tar,  mcq_correct_value);





fs.writeFileSync('ps_cpl_audio_G3_12.json', JSON.stringify(tar));
